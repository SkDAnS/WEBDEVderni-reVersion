package fr.isen.ticketapp.interfaces.models;

import fr.isen.ticketapp.interfaces.models.enums.ETATSPOSTES;

//begin of modifiable zone(Javadoc).......C/66246da2-6fc4-44aa-a192-b60a7403e3f1

//end of modifiable zone(Javadoc).........E/66246da2-6fc4-44aa-a192-b60a7403e3f1
public class PosteInformatiqueModel {
//begin of modifiable zone(Javadoc).......C/1d5333c7-a341-4740-ab10-a1adc384ca12

//end of modifiable zone(Javadoc).........E/1d5333c7-a341-4740-ab10-a1adc384ca12
    private int id;

//begin of modifiable zone(Javadoc).......C/922bc28e-0c40-4aef-9bef-3675b6d05163

//end of modifiable zone(Javadoc).........E/922bc28e-0c40-4aef-9bef-3675b6d05163
    public UtilisateurModel utilisateurAffecte;

//begin of modifiable zone(Javadoc).......C/f92867d4-0d55-4503-945a-f397233e487d

//end of modifiable zone(Javadoc).........E/f92867d4-0d55-4503-945a-f397233e487d
    public ETATSPOSTES etat;

//begin of modifiable zone(Javadoc).......C/4a204814-7de5-4bb2-816e-08887993415f

//end of modifiable zone(Javadoc).........E/4a204814-7de5-4bb2-816e-08887993415f
    public String configuration;

}
