package fr.isen.ticketapp.interfaces.models.enums;


//begin of modifiable zone(Javadoc).......C/a105e75b-0f7f-4978-9676-1a85d9f223a3

//end of modifiable zone(Javadoc).........E/a105e75b-0f7f-4978-9676-1a85d9f223a3
public enum ETATSPOSTES {
//begin of modifiable zone(Javadoc).......C/6e20f1e3-755d-4b43-8e6d-c5aecf225fad

//end of modifiable zone(Javadoc).........E/6e20f1e3-755d-4b43-8e6d-c5aecf225fad
    ENFONCTION,
//begin of modifiable zone(Javadoc).......C/de09181a-8a8a-408c-a03d-7b3531447731

//end of modifiable zone(Javadoc).........E/de09181a-8a8a-408c-a03d-7b3531447731
    ENMAINTENANCE,
//begin of modifiable zone(Javadoc).......C/be7abec7-5ce3-499c-8578-0cc25dbd08ac

//end of modifiable zone(Javadoc).........E/be7abec7-5ce3-499c-8578-0cc25dbd08ac
    ENCOMMANDE;
}
