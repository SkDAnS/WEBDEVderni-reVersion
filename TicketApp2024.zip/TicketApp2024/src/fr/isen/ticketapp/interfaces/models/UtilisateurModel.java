package fr.isen.ticketapp.interfaces.models;

import java.util.Date;
import fr.isen.ticketapp.interfaces.models.enums.STATUTS;

//begin of modifiable zone(Javadoc).......C/ca267fbb-a7a6-4d67-a6ed-b315f38816b4

//end of modifiable zone(Javadoc).........E/ca267fbb-a7a6-4d67-a6ed-b315f38816b4
public class UtilisateurModel {
//begin of modifiable zone(Javadoc).......C/5ab664da-3414-4fd5-84f6-3dd6ff438b3a

//end of modifiable zone(Javadoc).........E/5ab664da-3414-4fd5-84f6-3dd6ff438b3a
    private int id;

//begin of modifiable zone(Javadoc).......C/63e66098-faac-4cba-8b61-933bba98fcdf

//end of modifiable zone(Javadoc).........E/63e66098-faac-4cba-8b61-933bba98fcdf
    public String nom;

//begin of modifiable zone(Javadoc).......C/6d3dadd7-e614-4bba-90a6-2efdd7ee9f41

//end of modifiable zone(Javadoc).........E/6d3dadd7-e614-4bba-90a6-2efdd7ee9f41
    public STATUTS statut;

//begin of modifiable zone(Javadoc).......C/d859dc65-220f-4081-9fbd-2af17d362f6f

//end of modifiable zone(Javadoc).........E/d859dc65-220f-4081-9fbd-2af17d362f6f
    public Date dateDerniereConnexion;

//begin of modifiable zone(Javadoc).......C/f24e369d-15f2-4d46-a0f3-af4b0e8430e4

//end of modifiable zone(Javadoc).........E/f24e369d-15f2-4d46-a0f3-af4b0e8430e4
    public String motDePasse;

//begin of modifiable zone(Javadoc).......C/5bcc4184-b1f2-4ca0-beb5-68ebe490408a

//end of modifiable zone(Javadoc).........E/5bcc4184-b1f2-4ca0-beb5-68ebe490408a
    public String email;

}
