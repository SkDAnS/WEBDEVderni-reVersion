package fr.isen.ticketapp.interfaces.models;

import java.util.Date;
import fr.isen.ticketapp.interfaces.models.enums.ETATSTICKETS;
import fr.isen.ticketapp.interfaces.models.enums.IMPACTS;

//begin of modifiable zone(Javadoc).......C/589af86d-951f-4907-b784-29412b402562

//end of modifiable zone(Javadoc).........E/589af86d-951f-4907-b784-29412b402562
public class TicketModel {
//begin of modifiable zone(Javadoc).......C/658a81e9-2ac9-42fe-98c4-fac8ca2d3d32

//end of modifiable zone(Javadoc).........E/658a81e9-2ac9-42fe-98c4-fac8ca2d3d32
    private int id;

//begin of modifiable zone(Javadoc).......C/4da3768f-d2ab-4070-b83b-c002264a9d55

//end of modifiable zone(Javadoc).........E/4da3768f-d2ab-4070-b83b-c002264a9d55
    public IMPACTS impact;

//begin of modifiable zone(Javadoc).......C/65004d8d-1cc9-43dc-9870-58248f2f27ce

//end of modifiable zone(Javadoc).........E/65004d8d-1cc9-43dc-9870-58248f2f27ce
    public String titre;

//begin of modifiable zone(Javadoc).......C/063571b9-879a-4d91-8993-661c54f68bcf

//end of modifiable zone(Javadoc).........E/063571b9-879a-4d91-8993-661c54f68bcf
    public String description;

//begin of modifiable zone(Javadoc).......C/53ce755c-b60d-4016-9cf0-49f12d8c70ff

//end of modifiable zone(Javadoc).........E/53ce755c-b60d-4016-9cf0-49f12d8c70ff
    public ETATSTICKETS état;

//begin of modifiable zone(Javadoc).......C/0c7c3452-8cd0-48b1-b7ba-ace04dbe011a

//end of modifiable zone(Javadoc).........E/0c7c3452-8cd0-48b1-b7ba-ace04dbe011a
    public String typeDeDemande;

//begin of modifiable zone(Javadoc).......C/85817229-34a2-4f08-acf3-4bd6bb3bf288

//end of modifiable zone(Javadoc).........E/85817229-34a2-4f08-acf3-4bd6bb3bf288
    public Date DateEtHeureCreationEtMiseAJour;

//begin of modifiable zone(Javadoc).......C/6653ce46-e38d-4e2e-9b2f-a2d7f3d39f6c

//end of modifiable zone(Javadoc).........E/6653ce46-e38d-4e2e-9b2f-a2d7f3d39f6c
    public UtilisateurModel UtilisateurCreateur;

//begin of modifiable zone(Javadoc).......C/5c6df6a9-5417-4e69-bd60-185af4f73750

//end of modifiable zone(Javadoc).........E/5c6df6a9-5417-4e69-bd60-185af4f73750
    public PosteInformatiqueModel PosteInformatique;

}
