package fr.isen.ticketapp.interfaces.models.enums;


//begin of modifiable zone(Javadoc).......C/5c8fe0e6-dde9-4f66-a9c7-09d266594c2a

//end of modifiable zone(Javadoc).........E/5c8fe0e6-dde9-4f66-a9c7-09d266594c2a
public enum IMPACTS {
//begin of modifiable zone(Javadoc).......C/c758aba7-40a7-4a14-9b8e-673b282b04e8

//end of modifiable zone(Javadoc).........E/c758aba7-40a7-4a14-9b8e-673b282b04e8
    BLOQUANT,
//begin of modifiable zone(Javadoc).......C/c8ca1f05-d5f0-4a81-bb1e-3d5193d65245

//end of modifiable zone(Javadoc).........E/c8ca1f05-d5f0-4a81-bb1e-3d5193d65245
    MINEUR,
//begin of modifiable zone(Javadoc).......C/1d62d774-90e5-48f2-86eb-7e36f7191eb2

//end of modifiable zone(Javadoc).........E/1d62d774-90e5-48f2-86eb-7e36f7191eb2
    MAJEUR;
}
