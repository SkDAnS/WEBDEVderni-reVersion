package fr.isen.ticketapp.interfaces.models.enums;


//begin of modifiable zone(Javadoc).......C/24bb9ebb-0cdf-4ecf-a927-7d5c03453a07

//end of modifiable zone(Javadoc).........E/24bb9ebb-0cdf-4ecf-a927-7d5c03453a07
public enum STATUTS {
//begin of modifiable zone(Javadoc).......C/863c0258-86db-4306-b0ed-bd88fcd5b054

//end of modifiable zone(Javadoc).........E/863c0258-86db-4306-b0ed-bd88fcd5b054
    ACTIF_OUI,
//begin of modifiable zone(Javadoc).......C/15fd6c01-ed30-4999-9410-4f110eca2476

//end of modifiable zone(Javadoc).........E/15fd6c01-ed30-4999-9410-4f110eca2476
    ACTIF_NON;
}
