package fr.isen.ticketapp.interfaces.models.enums;


//begin of modifiable zone(Javadoc).......C/f3cfc8c9-e784-4550-a265-64341ba53e4d

//end of modifiable zone(Javadoc).........E/f3cfc8c9-e784-4550-a265-64341ba53e4d
public enum ETATSTICKETS {
//begin of modifiable zone(Javadoc).......C/fdbfabcc-de79-4927-899b-17e07faaf1be

//end of modifiable zone(Javadoc).........E/fdbfabcc-de79-4927-899b-17e07faaf1be
    OUVERT,
//begin of modifiable zone(Javadoc).......C/b81e25cd-8ecc-4d7e-bdb1-ce602af0db66

//end of modifiable zone(Javadoc).........E/b81e25cd-8ecc-4d7e-bdb1-ce602af0db66
    EN COURS,
//begin of modifiable zone(Javadoc).......C/7b79771a-aa0a-4534-bd48-a22843aca937

//end of modifiable zone(Javadoc).........E/7b79771a-aa0a-4534-bd48-a22843aca937
    RESOLU,
//begin of modifiable zone(Javadoc).......C/313f1b70-0d1d-493e-9fe9-fcfa3ee96871

//end of modifiable zone(Javadoc).........E/313f1b70-0d1d-493e-9fe9-fcfa3ee96871
    FERME,
//begin of modifiable zone(Javadoc).......C/ec96c2ec-d720-44e6-a627-e0ec03060737

//end of modifiable zone(Javadoc).........E/ec96c2ec-d720-44e6-a627-e0ec03060737
    ANNULE;
}
